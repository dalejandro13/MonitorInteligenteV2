﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace com.flexolumens.rutas
{
    public class RoutesListAdapter : BaseAdapter<Routes>
    {
        List<Routes> routes;

        public RoutesListAdapter(List<Routes> users)
        {
            this.routes = users;
        }

        public override Routes this[int position]
        {
            get
            {
                return routes[position];
            }
        }

        public override int Count
        {
            get
            {
                return routes.Count;
            }
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var view = convertView;

            if (view == null)
            {
                view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.routesRow, parent, false);

                var photo = view.FindViewById<ImageView>(Resource.Id.logoImageView);
                var name = view.FindViewById<TextView>(Resource.Id.nameTextView);

                view.Tag = new ViewHolder() { Photo = photo, Name = name};
            }

            var holder = (ViewHolder)view.Tag;

            holder.Photo.SetImageDrawable(ImageManager.Get(parent.Context, routes[position].ImageUrl));
            holder.Name.Text = routes[position].Name;


            return view;

        }
    }
}