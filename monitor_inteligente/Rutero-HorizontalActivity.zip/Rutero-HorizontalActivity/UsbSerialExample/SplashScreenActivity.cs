﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace com.flexolumens.rutas
{
    [Activity(Label = "@string/app_name", MainLauncher = true, NoHistory = true, Icon = "@drawable/ic_launcher", Theme = "@android:style/Theme.Material.NoActionBar.Fullscreen", ScreenOrientation = ScreenOrientation.Portrait)]
    public class SplashScreenActivity : Activity
    {
        protected async override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.splash_screen);
            
            
        }


        protected async override void OnResume()
        {
            base.OnResume();
            await Task.Delay(3000);
            StartActivity(typeof(DeviceListActivity));
        }
    }
}