﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace com.flexolumens.rutas
{
    public static class RoutesData
    {
        public static List<Routes> Route { get; private set; }

        static RoutesData()
        {
            var temp = new List<Routes>();

            AddRoute(temp);

            Route = temp.ToList();
        }

        static void AddRoute(List<Routes> route)
        {
            string allText;
            try
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file;
                string data = string.Empty;
                if (File.Exists("/sdcard/Download/rutas.flexo"))
                {
                    file = File.Open("/sdcard/Download/rutas.flexo", FileMode.Open);
                    data = (string)bf.Deserialize(file);
                    file.Close();

                }
                System.IO.StringReader routeIndex = new System.IO.StringReader(data);
                

                while ((allText = routeIndex.ReadLine()) != null)
                {
                    route.Add(new Routes()
                    {
                        Name = allText,
                        ImageUrl = "images/usb_on.png"

                    });
                }
                
                routeIndex.Close();
            }
            catch (Exception ex)
            {

            }
        }
    }
}