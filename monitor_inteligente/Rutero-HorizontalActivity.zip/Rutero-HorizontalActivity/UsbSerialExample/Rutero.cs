﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace com.flexolumens.rutas
{
    public class Rutero
    {
        public string Name { get; set; }
        public string DynamicKey { get; set; }
        public int Type { get; set; }
        public List<Module> Modules { get; set; }
        public int LastCheckState { get; set; }
        public List<int> BrokenModulesIndex { get; set; }

        public Rutero(string name, string dynamicKey, int type, List<Module> modules)
        {
            Name = name;
            Type = type;
            Modules = modules;
            LastCheckState = 2;
            DynamicKey = dynamicKey;
        }

        public void SetNewCheck(List<Module> revModules)
        {
            BrokenModulesIndex = new List<int>();

            for (int i = 0; i < revModules.Count; i++)
            {
                if (!revModules[i].State)
                {
                    BrokenModulesIndex.Add(revModules[i].Index); 
                }
            }
        }
    }
    
}