﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Hardware.Usb;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Hoho.Android.UsbSerial.Driver;
using Hoho.Android.UsbSerial.Util;
using System.Globalization;
using System.Threading;
using Android.Content.PM;

[assembly: UsesFeature ("android.hardware.usb.host")]

namespace com.flexolumens.rutas
{
	[Activity (Label = "@string/app_name",
        Icon = "@drawable/ic_launcher",
        ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation,
        Theme = "@style/SerialTheme",
        ScreenOrientation = ScreenOrientation.Portrait)]

	[IntentFilter (new[] { UsbManager.ActionUsbDeviceAttached })]

	[MetaData (UsbManager.ActionUsbDeviceAttached, Resource = "@xml/device_filter")]

	class DeviceListActivity : Activity
	{
		static readonly string TAG = typeof(DeviceListActivity).Name;
		const string ACTION_USB_PERMISSION = "com.hoho.android.usbserial.examples.USB_PERMISSION";
		UsbManager usbManager;
		ListView listView;
		TextView progressBarTitle;
		ProgressBar progressBar;
        Button btnBack;

		UsbSerialPortAdapter adapter;
		BroadcastReceiver detachedReceiver;
		IUsbSerialPort selectedPort;
        private bool firstTime = true;
        private bool alertFirstTime = true;

        protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			SetContentView (Resource.Layout.Main);
			usbManager = GetSystemService(Context.UsbService) as UsbManager;
			listView = FindViewById<ListView>(Resource.Id.deviceList);
			progressBar = FindViewById<ProgressBar>(Resource.Id.progressBar);
			progressBarTitle = FindViewById<TextView>(Resource.Id.progressBarTitle);
            //btnBack = FindViewById<Button>(Resource.Id.sendButtonMain);

            Thread.Sleep(2000);
            Window.DecorView.SystemUiVisibility = (StatusBarVisibility)View.SystemUiFlagHideNavigation;

            Thread.Sleep(2000);
            Window.DecorView.SystemUiVisibility = (StatusBarVisibility)View.SystemUiFlagVisible;


            /*btnBack.Click += async delegate
            {
                Finish();
            };*/


        }

        [Java.Interop.Export("button_OnClick")]
        public void button_OnClick(View v)
        {
            this.Finish();
            return;
        }

        [Java.Interop.Export("shutdown_OnClick")]
        public void shutdown_OnClick(View v)
        {
            Java.Lang.Runtime.GetRuntime().Exec(new String[] { "/system/xbin/su", "-c", "reboot -p" });
        }

        private async void StartSerial()
        {
            try
            {
                if (firstTime)
                {
                    Thread.Sleep(5000);
                    Log.Info(TAG, "Pressed item " + 0);
                    if (0 >= adapter.Count)
                    {
                        Log.Info(TAG, "Illegal position.");
                        return;
                    }

                    if (adapter.Count != 0)
                    {
                        selectedPort = adapter.GetItem(0);
                        var permissionGranted = await usbManager.RequestPermissionAsync(selectedPort.Driver.Device, this);
                        if (permissionGranted)
                        {
                            var newIntent = new Intent(this, typeof(SerialConsoleActivity));
                            newIntent.SetFlags(newIntent.Flags | ActivityFlags.NoHistory);
                            newIntent.PutExtra(SerialConsoleActivity.EXTRA_TAG, new UsbSerialPortInfo(selectedPort));
                            StartActivity(newIntent);
                            //Finish();
                        }
                    }
                    firstTime = false;
                }
            }
            catch (Exception)
            {
                StartSerial();
            }
        }

		protected override async void OnResume ()
		{
			base.OnResume ();
			adapter = new UsbSerialPortAdapter (this);
			listView.Adapter = adapter;

			listView.ItemClick += async (sender, e) => {
				await OnItemClick(sender, e);
			};

			await PopulateListAsync();

            View decorView = Window.DecorView;
            var uiOptions = (int)decorView.SystemUiVisibility;
            var newUiOptions = (int)uiOptions;

            newUiOptions |= (int)SystemUiFlags.LowProfile;
            newUiOptions |= (int)SystemUiFlags.Fullscreen;
            newUiOptions |= (int)SystemUiFlags.HideNavigation;
            newUiOptions |= (int)SystemUiFlags.Immersive;

            decorView.SystemUiVisibility = (StatusBarVisibility)newUiOptions;

            detachedReceiver = new UsbDeviceDetachedReceiver (this);
			RegisterReceiver(detachedReceiver, new IntentFilter(UsbManager.ActionUsbDeviceDetached));
            
            var startTimeSpan = TimeSpan.Zero;
            var periodTimeSpan = TimeSpan.FromSeconds(10);
            var timer = new System.Threading.Timer((e) =>
            {
                if (adapter != null)
                {
                    StartSerial();
                }
            }, null, startTimeSpan, periodTimeSpan);

        }

		protected override void OnPause ()
		{
			base.OnPause ();
            
			var temp = detachedReceiver; 
			if(temp != null)
				UnregisterReceiver (temp);
		}

        protected override void OnDestroy ()
		{
			base.OnDestroy ();

		}

		internal static Task<IList<IUsbSerialDriver>> FindAllDriversAsync(UsbManager usbManager)
		{
			var table = UsbSerialProber.DefaultProbeTable;
			table.AddProduct(0x1b4f, 0x0008, Java.Lang.Class.FromType(typeof(CdcAcmSerialDriver)));
			table.AddProduct(0x1b4f, 0x0008, Java.Lang.Class.FromType(typeof(Cp21xxSerialDriver)));
			var prober = new UsbSerialProber (table);
            return prober.FindAllDriversAsync (usbManager);
        }

		async Task OnItemClick(object sender, AdapterView.ItemClickEventArgs e)
		{
			Log.Info(TAG, "Pressed item " + e.Position);
			if (e.Position >= adapter.Count) {
				Log.Info(TAG, "Illegal position.");
				return;
			}
            
			selectedPort = adapter.GetItem(e.Position);
			var permissionGranted = await usbManager.RequestPermissionAsync(selectedPort.Driver.Device, this);
			if(permissionGranted) {
				var newIntent = new Intent (this, typeof(SerialConsoleActivity));
                newIntent.SetFlags(newIntent.Flags | ActivityFlags.NoHistory);
                newIntent.PutExtra (SerialConsoleActivity.EXTRA_TAG, new UsbSerialPortInfo(selectedPort));
				StartActivity (newIntent);
			}
		}

        async Task PopulateListAsync ()
		{
			ShowProgressBar ();

			Log.Info (TAG, "Refrescando dispositivos...");

			var drivers = await FindAllDriversAsync (usbManager);

			adapter.Clear ();
			foreach (var driver in drivers) {
				var ports = driver.Ports;
				Log.Info (TAG, string.Format ("+ {0}: {1} puerto{2}", driver, ports.Count, ports.Count == 1 ? string.Empty : "s"));
				foreach(var port in ports)
					adapter.Add (port);
			}

			adapter.NotifyDataSetChanged();
			progressBarTitle.Text = string.Format("{0} dispositivo{1} encontrados", adapter.Count, adapter.Count == 1 ? string.Empty : "s");
			HideProgressBar();
			Log.Info(TAG, "Done refreshing, " + adapter.Count + " entries found.");
            
        }

		void ShowProgressBar()
		{
			progressBar.Visibility = ViewStates.Visible;
			progressBarTitle.Text = GetString(Resource.String.refreshing);
		}

		void HideProgressBar()
		{
			progressBar.Visibility = ViewStates.Invisible;
		}

		#region UsbSerialPortAdapter implementation

		class UsbSerialPortAdapter : ArrayAdapter<IUsbSerialPort>
		{
			public UsbSerialPortAdapter(Context context)
				: base(context, global::Android.Resource.Layout.SimpleExpandableListItem2)
			{
			}

			public override View GetView (int position, View convertView, ViewGroup parent)
			{
				var row = convertView;
				if (row == null) {
					var inflater = Context.GetSystemService (Context.LayoutInflaterService) as LayoutInflater;
					row = inflater.Inflate (global::Android.Resource.Layout.SimpleListItem2, null);
				}

				var port = this.GetItem(position);
				var driver = port.Driver;
				var device = driver.Device;

				var title = string.Format ("Rutero {0} Srl {1}",
					HexDump.ToHexString ((short)device.VendorId),
					HexDump.ToHexString ((short)device.ProductId));
				row.FindViewById<TextView> (global::Android.Resource.Id.Text1).Text = title;

				var subtitle = device.Class.SimpleName;
				row.FindViewById<TextView> (global::Android.Resource.Id.Text2).Text = subtitle;

				return row;
			}
		}

		#endregion

		#region UsbDeviceDetachedReceiver implementation

		class UsbDeviceDetachedReceiver
			: BroadcastReceiver
		{
			readonly string TAG = typeof(UsbDeviceDetachedReceiver).Name;
			readonly DeviceListActivity activity;

			public UsbDeviceDetachedReceiver(DeviceListActivity activity)
			{
				this.activity = activity;
			}

			public override void OnReceive (Context context, Intent intent)
			{
				var device = intent.GetParcelableExtra(UsbManager.ExtraDevice) as UsbDevice;

				Log.Info (TAG, "USB device detached: " + device.DeviceName);

				activity.PopulateListAsync ();
			}
		}

		#endregion
	}
}


