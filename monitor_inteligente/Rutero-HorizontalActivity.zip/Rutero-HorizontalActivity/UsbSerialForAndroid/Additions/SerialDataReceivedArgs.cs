﻿
using System;

namespace Hoho.Android.UsbSerial.Util
{
	public class SerialDataReceivedArgs : EventArgs
	{
		public SerialDataReceivedArgs (byte[] data)
		{
			Data = data;
		}

		public byte[] Data { get; private set; }
	}
}

