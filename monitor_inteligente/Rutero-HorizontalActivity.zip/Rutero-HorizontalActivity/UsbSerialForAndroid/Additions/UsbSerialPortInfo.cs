﻿

using System;
using Android.OS;
using Android.Util;
using Java.Interop;
using Hoho.Android.UsbSerial.Driver;

namespace Hoho.Android.UsbSerial.Util
{
	public sealed class UsbSerialPortInfo : Java.Lang.Object, IParcelable
	{
		static readonly IParcelableCreator creator = new ParcelableCreator();

		[ExportField("CREATOR")]
		public static IParcelableCreator GetCreator()
		{
			return creator;
		}

		public UsbSerialPortInfo ()
		{
		}

		public UsbSerialPortInfo (IUsbSerialPort port)
		{
			var device = port.Driver.Device;
			VendorId = device.VendorId;
			DeviceId = device.DeviceId;
			PortNumber = port.PortNumber;
		}

		private UsbSerialPortInfo(Parcel parcel)
		{
			VendorId = parcel.ReadInt ();
			DeviceId = parcel.ReadInt ();
			PortNumber = parcel.ReadInt ();
		}

		public int VendorId { get; set; }

		public int DeviceId { get; set; }

		public int PortNumber { get; set; }

		#region IParcelable implementation

		public int DescribeContents ()
		{
			return 0;
		}

		public void WriteToParcel (Parcel dest, ParcelableWriteFlags flags)
		{
			dest.WriteInt(VendorId);
			dest.WriteInt(DeviceId);
			dest.WriteInt(PortNumber);
		}

		#endregion

		#region ParcelableCreator implementation
        
		public sealed class ParcelableCreator : Java.Lang.Object, IParcelableCreator
		{
			#region IParcelableCreator implementation

			public Java.Lang.Object CreateFromParcel(Parcel parcel)
			{
				return new UsbSerialPortInfo (parcel);
			}

			public Java.Lang.Object[] NewArray(int size)
			{
				return new UsbSerialPortInfo[size];
			}

			#endregion
		}

		#endregion
	}
}

