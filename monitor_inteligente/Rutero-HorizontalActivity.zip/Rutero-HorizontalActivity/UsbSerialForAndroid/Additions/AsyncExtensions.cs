﻿

using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Android.Hardware.Usb;

namespace Hoho.Android.UsbSerial.Driver
{
	public static partial class AsyncExtensions
	{
		public static Task<IList<IUsbSerialDriver>> FindAllDriversAsync(this UsbSerialProber prober, UsbManager manager)
		{
			var tcs = new TaskCompletionSource<IList<IUsbSerialDriver>> ();
			Task.Run(() => {
				tcs.TrySetResult(prober.FindAllDrivers(manager));
			});
			return tcs.Task;
		}
	}
}

